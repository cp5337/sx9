#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════
# SX9 Threat Intelligence Master Pipeline
# ═══════════════════════════════════════════════════════════════════════════
# 
# Downloads → Normalizes → Loads to Supabase
#
# Usage:
#   ./master_pipeline.sh              # Full pipeline
#   ./master_pipeline.sh --skip-download   # Skip download, normalize existing
#   ./master_pipeline.sh --normalize-only  # Only normalize
#   ./master_pipeline.sh --load-only       # Only load to Supabase
#
# ═══════════════════════════════════════════════════════════════════════════

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Directories
DOWNLOAD_DIR="$SCRIPT_DIR/node-interview-generator/output/threat_content"
NORMALIZED_DIR="$SCRIPT_DIR/normalized"
LOG_DIR="$SCRIPT_DIR/logs"

mkdir -p "$LOG_DIR"
mkdir -p "$NORMALIZED_DIR"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOG_FILE="$LOG_DIR/master_pipeline_${TIMESTAMP}.log"

# ═══════════════════════════════════════════════════════════════════════════
# Logging
# ═══════════════════════════════════════════════════════════════════════════

log() {
    echo -e "${GREEN}[$(date +%H:%M:%S)]${NC} $1" | tee -a "$LOG_FILE"
}

warn() {
    echo -e "${YELLOW}[$(date +%H:%M:%S)] ⚠️  $1${NC}" | tee -a "$LOG_FILE"
}

error() {
    echo -e "${RED}[$(date +%H:%M:%S)] ❌ $1${NC}" | tee -a "$LOG_FILE"
}

header() {
    echo -e "\n${BLUE}═══════════════════════════════════════════════════════════════${NC}" | tee -a "$LOG_FILE"
    echo -e "${BLUE} $1${NC}" | tee -a "$LOG_FILE"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}\n" | tee -a "$LOG_FILE"
}

# ═══════════════════════════════════════════════════════════════════════════
# Parse Arguments
# ═══════════════════════════════════════════════════════════════════════════

SKIP_DOWNLOAD=false
NORMALIZE_ONLY=false
LOAD_ONLY=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --skip-download)
            SKIP_DOWNLOAD=true
            shift
            ;;
        --normalize-only)
            NORMALIZE_ONLY=true
            shift
            ;;
        --load-only)
            LOAD_ONLY=true
            shift
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

# ═══════════════════════════════════════════════════════════════════════════
# Check Environment
# ═══════════════════════════════════════════════════════════════════════════

header "SX9 Threat Intelligence Master Pipeline"

log "Checking environment..."

# Check Python
if ! command -v python3 &> /dev/null; then
    error "Python3 not found"
    exit 1
fi

# Check for mmh3
if python3 -c "import mmh3" 2>/dev/null; then
    log "✅ mmh3 (Murmur3) available"
else
    warn "mmh3 not installed. Using fallback hashing."
    warn "Install with: pip install mmh3"
fi

# Check for yaml
if python3 -c "import yaml" 2>/dev/null; then
    log "✅ PyYAML available"
else
    error "PyYAML not installed. Install with: pip install pyyaml"
    exit 1
fi

# Check Supabase credentials
if [[ -z "$SUPABASE_URL" ]] || [[ -z "$SUPABASE_KEY" ]]; then
    warn "SUPABASE_URL or SUPABASE_KEY not set. Load step will be skipped."
    SKIP_LOAD=true
else
    log "✅ Supabase credentials found"
    SKIP_LOAD=false
fi

# ═══════════════════════════════════════════════════════════════════════════
# Phase 1: Download
# ═══════════════════════════════════════════════════════════════════════════

if [[ "$NORMALIZE_ONLY" == false ]] && [[ "$LOAD_ONLY" == false ]] && [[ "$SKIP_DOWNLOAD" == false ]]; then
    header "Phase 1: Download Threat Intelligence"
    
    log "Starting threat content download..."
    log "This will take 30-60 minutes."
    log "Output: $DOWNLOAD_DIR"
    
    cd "$SCRIPT_DIR/node-interview-generator"
    
    # Run the downloader
    python3 threat_content_fetcher.py --all --no-training 2>&1 | tee -a "$LOG_FILE"
    
    if [[ $? -eq 0 ]]; then
        log "✅ Download complete"
    else
        error "Download failed"
        exit 1
    fi
    
    cd "$SCRIPT_DIR"
else
    if [[ "$SKIP_DOWNLOAD" == true ]]; then
        log "Skipping download (--skip-download)"
    fi
fi

# ═══════════════════════════════════════════════════════════════════════════
# Phase 2: Normalize
# ═══════════════════════════════════════════════════════════════════════════

if [[ "$LOAD_ONLY" == false ]]; then
    header "Phase 2: Normalize Data"
    
    log "Normalizing threat intelligence data..."
    log "Input: $DOWNLOAD_DIR"
    log "Output: $NORMALIZED_DIR"
    
    python3 normalize_threat_intel.py \
        --input "$DOWNLOAD_DIR" \
        --output "$NORMALIZED_DIR" \
        2>&1 | tee -a "$LOG_FILE"
    
    if [[ $? -eq 0 ]]; then
        log "✅ Normalization complete"
        
        # Show stats
        log "Output files:"
        ls -lh "$NORMALIZED_DIR"/*.json "$NORMALIZED_DIR"/*.csv "$NORMALIZED_DIR"/*.sql 2>/dev/null | tee -a "$LOG_FILE"
    else
        error "Normalization failed"
        exit 1
    fi
fi

# ═══════════════════════════════════════════════════════════════════════════
# Phase 3: Load to Supabase
# ═══════════════════════════════════════════════════════════════════════════

if [[ "$NORMALIZE_ONLY" == false ]] && [[ "$SKIP_LOAD" == false ]]; then
    header "Phase 3: Load to Supabase"
    
    log "Applying schema..."
    
    # Apply schema first
    if command -v psql &> /dev/null; then
        # Extract host from SUPABASE_URL
        DB_HOST=$(echo "$SUPABASE_URL" | sed 's|https://||' | sed 's|.supabase.co.*||')
        
        log "Running schema_threat_intel.sql..."
        # Note: You'd need to construct proper connection string
        # psql "$DATABASE_URL" -f schema_threat_intel.sql
        warn "Manual step: Run schema_threat_intel.sql in Supabase SQL Editor"
    else
        warn "psql not found. Manual step: Run schema_threat_intel.sql in Supabase SQL Editor"
    fi
    
    log "Loading normalized data..."
    
    # Load via Python
    python3 << 'EOF'
import os
import json
from pathlib import Path

try:
    from supabase import create_client
except ImportError:
    print("⚠️  supabase-py not installed. pip install supabase")
    exit(1)

url = os.environ.get('SUPABASE_URL')
key = os.environ.get('SUPABASE_KEY')

if not url or not key:
    print("❌ SUPABASE_URL and SUPABASE_KEY required")
    exit(1)

supabase = create_client(url, key)

normalized_dir = Path('./normalized')

# Load techniques
print("Loading techniques...")
with open(normalized_dir / 'techniques.json') as f:
    techniques = json.load(f)

for tech in techniques[:500]:  # Batch limit
    try:
        supabase.table('techniques').upsert(tech).execute()
    except Exception as e:
        print(f"  Error: {e}")

print(f"✅ Loaded {min(len(techniques), 500)} techniques")

# Load tools
print("Loading tools...")
with open(normalized_dir / 'tools.json') as f:
    tools = json.load(f)

for tool in tools[:1000]:  # Batch limit
    try:
        supabase.table('tools').upsert(tool).execute()
    except Exception as e:
        print(f"  Error: {e}")

print(f"✅ Loaded {min(len(tools), 1000)} tools")

# Load mappings
print("Loading tool→technique mappings...")
with open(normalized_dir / 'tool_technique_map.json') as f:
    mappings = json.load(f)

for mapping in mappings[:2000]:
    try:
        supabase.table('tool_technique_map').upsert(mapping).execute()
    except Exception as e:
        pass  # Skip FK errors silently

print(f"✅ Loaded mappings")
print("Done!")
EOF
    
    if [[ $? -eq 0 ]]; then
        log "✅ Supabase load complete"
    else
        warn "Supabase load had errors (some expected for missing FKs)"
    fi
fi

# ═══════════════════════════════════════════════════════════════════════════
# Summary
# ═══════════════════════════════════════════════════════════════════════════

header "Pipeline Complete"

log "Summary:"
log "  Log file: $LOG_FILE"
log "  Normalized data: $NORMALIZED_DIR"

if [[ -f "$NORMALIZED_DIR/tools.json" ]]; then
    TOOL_COUNT=$(python3 -c "import json; print(len(json.load(open('$NORMALIZED_DIR/tools.json'))))")
    TECH_COUNT=$(python3 -c "import json; print(len(json.load(open('$NORMALIZED_DIR/techniques.json'))))" 2>/dev/null || echo "0")
    MAP_COUNT=$(python3 -c "import json; print(len(json.load(open('$NORMALIZED_DIR/tool_technique_map.json'))))" 2>/dev/null || echo "0")
    
    log ""
    log "  Tools: $TOOL_COUNT"
    log "  Techniques: $TECH_COUNT"
    log "  Tool→Technique mappings: $MAP_COUNT"
fi

log ""
log "Next steps:"
log "  1. Run schema in Supabase: schema_threat_intel.sql"
log "  2. Load seed data: seed_all.sql"
log "  3. Start Kali daemon: cd sx9-kali-daemon && cargo run"
log ""
log "🎯 Done!"
