# SX9 Threat Intelligence Pipeline

**Normalized data flow from 27 sources to Supabase**

## Quick Start

```bash
cd /Users/cp5337/Developer/sx9/tools/abe/iac

# Full pipeline (download → normalize → load)
./master_pipeline.sh

# Or step by step:
./master_pipeline.sh --skip-download    # Use existing downloads
./master_pipeline.sh --normalize-only   # Just normalize
./master_pipeline.sh --load-only        # Just load to Supabase
```

## Pipeline Phases

### Phase 1: Download (~30-60 min)
Downloads raw threat intelligence from 27 sources:

| Source | Type | Count |
|--------|------|-------|
| MITRE ATT&CK | Techniques | ~700 |
| Atomic Red Team | Tests | ~1000 |
| Caldera | Abilities | ~500 |
| Nuclei | Templates | ~8000 |
| Sigma | Detection rules | ~2000 |
| YARA | Signatures | ~1000 |
| Kali Tools | Tools | ~600 |
| LOLBAS | Windows bins | ~200 |
| GTFOBins | Unix bins | ~300 |
| + 18 more... | | |

### Phase 2: Normalize
Converts raw data to normalized schema with RFC-9001 hashes:

```
Raw YAML/JSON → Normalized Tool/Technique → Trivariate Hash → Unicode Rune
```

**Output files:**
- `normalized/tools.json` - All tools with hashes
- `normalized/techniques.json` - MITRE ATT&CK techniques
- `normalized/tool_technique_map.json` - Tool→Technique mappings
- `normalized/playbooks.json` - Generated tool chains
- `normalized/seed_all.sql` - SQL for Supabase

### Phase 3: Load to Supabase
Loads normalized data into Supabase tables:

```
tools              → All tools from all sources
techniques         → MITRE ATT&CK techniques
tool_technique_map → Tool→Technique relationships
```

## Schema

```sql
-- Core tables
tools                 -- Unified tool registry
techniques            -- MITRE ATT&CK
tool_technique_map    -- Tool → Technique
task_technique_map    -- CTAS Task → Technique

-- Views
v_tools_with_techniques
v_techniques_with_tools
v_task_tool_chain
v_threat_intel_stats
```

## Data Model

```
┌─────────────────┐     ┌─────────────────┐
│   techniques    │     │     tools       │
│ (MITRE ATT&CK)  │     │ (All sources)   │
├─────────────────┤     ├─────────────────┤
│ id (T1234.001)  │◄───┐│ id              │
│ name            │    ││ name            │
│ tactic          │    ││ source          │
│ h1_operational  │    ││ unicode_rune    │
└─────────────────┘    │└─────────────────┘
         ▲             │         │
         │             │         │
┌────────┴─────────────┴─────────┴────────┐
│         tool_technique_map              │
├─────────────────────────────────────────┤
│ tool_id, technique_id, source, confidence│
└─────────────────────────────────────────┘
```

## RFC-9001 Hashes

Every tool gets:
- `h1_operational` - 48 hex chars (SCH + CUID + UUID)
- `h1_sch` - 16 hex chars (Semantic Content Hash)
- `h1_cuid` - 16 hex chars (Content Unique ID)
- `h1_uuid` - 16 hex chars (UUID component)
- `h2_semantic` - 16 hex chars (Hash of H1)
- `unicode_rune` - E0xx (Class A tool rune)

## Files

```
/Users/cp5337/Developer/sx9/tools/abe/iac/
├── master_pipeline.sh           # Master orchestrator
├── normalize_threat_intel.py    # Normalization engine
├── schema_threat_intel.sql      # Supabase schema
├── threat_content_fetcher.py    # Downloader (existing)
└── normalized/                  # Output directory
    ├── tools.json
    ├── techniques.json
    ├── tool_technique_map.json
    ├── playbooks.json
    └── seed_all.sql
```

## Environment

```bash
# Required
pip install pyyaml

# Recommended
pip install mmh3        # Murmur3 hashing
pip install supabase    # Supabase client

# Supabase credentials
export SUPABASE_URL="https://xxx.supabase.co"
export SUPABASE_KEY="eyJ..."
```

## Integration with Kali Daemon

After pipeline completes:

```bash
# Start Kali daemon
cd /Users/cp5337/Developer/sx9/crates/sx9-kali-daemon
cargo run

# Daemon reads tools from:
# 1. smart-crate.toml (local registry)
# 2. Supabase tools table (if connected)
```

## Stats (Expected)

After full pipeline:

| Metric | Count |
|--------|-------|
| Total tools | ~12,000 |
| Techniques | ~700 |
| Tool→Technique maps | ~5,000 |
| Playbooks | ~200 |
| Sources | 27 |
