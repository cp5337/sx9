-- ═══════════════════════════════════════════════════════════════════════════
-- SX9 Threat Intelligence Schema
-- Normalized tables for tools, techniques, and mappings
-- ═══════════════════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────────────────────────────────────
-- TECHNIQUES (MITRE ATT&CK)
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS techniques (
    id TEXT PRIMARY KEY,                    -- T1234 or T1234.001
    name TEXT NOT NULL,
    tactic TEXT NOT NULL,                   -- reconnaissance, execution, etc
    description TEXT,
    detection TEXT,
    platforms TEXT[] DEFAULT '{}',
    data_sources TEXT[] DEFAULT '{}',
    
    -- RFC-9001 Hashes
    h1_operational TEXT,
    h2_semantic TEXT,
    
    -- Metadata
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_techniques_tactic ON techniques(tactic);
CREATE INDEX IF NOT EXISTS idx_techniques_h2 ON techniques(h2_semantic);

-- ─────────────────────────────────────────────────────────────────────────────
-- TOOLS (Unified registry from all sources)
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS tools (
    id TEXT PRIMARY KEY,                    -- kali-nmap, atomic-t1234-0, etc
    name TEXT NOT NULL,
    source TEXT NOT NULL,                   -- kali, atomic, caldera, nuclei, lolbas, gtfobins, sigma
    category TEXT NOT NULL,
    description TEXT,
    command TEXT,
    default_args TEXT[] DEFAULT '{}',
    url TEXT,
    
    -- HD4 & PTCC
    hd4_phase TEXT DEFAULT 'Hunt' CHECK (hd4_phase IN ('Hunt', 'Detect', 'Disrupt', 'Disable', 'Dominate')),
    ptcc_primitive INTEGER DEFAULT 1,       -- 0-31 per RFC-9100
    
    -- RFC-9001 Hashes
    h1_operational TEXT,
    h1_sch TEXT,
    h1_cuid TEXT,
    h1_uuid TEXT,
    h2_semantic TEXT,
    unicode_rune TEXT,                      -- E0xx
    
    -- Operational
    installed BOOLEAN DEFAULT false,
    success_rate INTEGER DEFAULT 85,
    last_used TIMESTAMPTZ,
    
    -- Metadata
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_tools_source ON tools(source);
CREATE INDEX IF NOT EXISTS idx_tools_category ON tools(category);
CREATE INDEX IF NOT EXISTS idx_tools_hd4_phase ON tools(hd4_phase);
CREATE INDEX IF NOT EXISTS idx_tools_h2 ON tools(h2_semantic);
CREATE INDEX IF NOT EXISTS idx_tools_rune ON tools(unicode_rune);

-- ─────────────────────────────────────────────────────────────────────────────
-- TOOL → TECHNIQUE MAPPING
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS tool_technique_map (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tool_id TEXT NOT NULL REFERENCES tools(id) ON DELETE CASCADE,
    technique_id TEXT NOT NULL REFERENCES techniques(id) ON DELETE CASCADE,
    source TEXT NOT NULL,                   -- Where mapping came from
    confidence FLOAT DEFAULT 1.0,           -- 0.0 - 1.0
    
    created_at TIMESTAMPTZ DEFAULT now(),
    
    UNIQUE(tool_id, technique_id)
);

CREATE INDEX IF NOT EXISTS idx_ttm_tool ON tool_technique_map(tool_id);
CREATE INDEX IF NOT EXISTS idx_ttm_technique ON tool_technique_map(technique_id);

-- ─────────────────────────────────────────────────────────────────────────────
-- TASK → TECHNIQUE MAPPING
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS task_technique_map (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id TEXT NOT NULL,                  -- References ctas_tasks.task_id
    technique_id TEXT NOT NULL REFERENCES techniques(id) ON DELETE CASCADE,
    coverage_type TEXT DEFAULT 'direct' CHECK (coverage_type IN ('direct', 'partial', 'related')),
    
    created_at TIMESTAMPTZ DEFAULT now(),
    
    UNIQUE(task_id, technique_id)
);

CREATE INDEX IF NOT EXISTS idx_task_tech_task ON task_technique_map(task_id);
CREATE INDEX IF NOT EXISTS idx_task_tech_technique ON task_technique_map(technique_id);

-- ─────────────────────────────────────────────────────────────────────────────
-- PLAYBOOK CHAINS (Updated)
-- ─────────────────────────────────────────────────────────────────────────────

-- Add columns to existing playbooks table if needed
ALTER TABLE playbooks 
    ADD COLUMN IF NOT EXISTS tool_ids TEXT[] DEFAULT '{}',
    ADD COLUMN IF NOT EXISTS technique_ids TEXT[] DEFAULT '{}',
    ADD COLUMN IF NOT EXISTS h1_operational TEXT,
    ADD COLUMN IF NOT EXISTS h2_semantic TEXT;

-- ─────────────────────────────────────────────────────────────────────────────
-- VIEWS
-- ─────────────────────────────────────────────────────────────────────────────

-- Tools with technique counts
CREATE OR REPLACE VIEW v_tools_with_techniques AS
SELECT 
    t.*,
    COUNT(ttm.technique_id) as technique_count,
    ARRAY_AGG(DISTINCT ttm.technique_id) FILTER (WHERE ttm.technique_id IS NOT NULL) as technique_ids
FROM tools t
LEFT JOIN tool_technique_map ttm ON t.id = ttm.tool_id
GROUP BY t.id;

-- Techniques with tool counts
CREATE OR REPLACE VIEW v_techniques_with_tools AS
SELECT 
    tech.*,
    COUNT(ttm.tool_id) as tool_count,
    ARRAY_AGG(DISTINCT ttm.tool_id) FILTER (WHERE ttm.tool_id IS NOT NULL) as tool_ids
FROM techniques tech
LEFT JOIN tool_technique_map ttm ON tech.id = ttm.technique_id
GROUP BY tech.id;

-- Tasks with techniques and tools (full chain)
CREATE OR REPLACE VIEW v_task_tool_chain AS
SELECT 
    ct.task_id,
    ct.task_name,
    ct.hd4_phase,
    ct.primitive_type,
    ARRAY_AGG(DISTINCT ttm.technique_id) as technique_ids,
    ARRAY_AGG(DISTINCT tool_tech.tool_id) as tool_ids
FROM ctas_tasks ct
LEFT JOIN task_technique_map ttm ON ct.task_id = ttm.task_id
LEFT JOIN tool_technique_map tool_tech ON ttm.technique_id = tool_tech.technique_id
GROUP BY ct.task_id, ct.task_name, ct.hd4_phase, ct.primitive_type;

-- ─────────────────────────────────────────────────────────────────────────────
-- FUNCTIONS
-- ─────────────────────────────────────────────────────────────────────────────

-- Get tools for a technique
CREATE OR REPLACE FUNCTION get_tools_for_technique(tech_id TEXT)
RETURNS TABLE (
    tool_id TEXT,
    tool_name TEXT,
    source TEXT,
    confidence FLOAT
) AS $$
BEGIN
    RETURN QUERY
    SELECT t.id, t.name, t.source, ttm.confidence
    FROM tools t
    JOIN tool_technique_map ttm ON t.id = ttm.tool_id
    WHERE ttm.technique_id = tech_id
    ORDER BY ttm.confidence DESC;
END;
$$ LANGUAGE plpgsql;

-- Get techniques for a tool
CREATE OR REPLACE FUNCTION get_techniques_for_tool(t_id TEXT)
RETURNS TABLE (
    technique_id TEXT,
    technique_name TEXT,
    tactic TEXT,
    confidence FLOAT
) AS $$
BEGIN
    RETURN QUERY
    SELECT tech.id, tech.name, tech.tactic, ttm.confidence
    FROM techniques tech
    JOIN tool_technique_map ttm ON tech.id = ttm.technique_id
    WHERE ttm.tool_id = t_id
    ORDER BY ttm.confidence DESC;
END;
$$ LANGUAGE plpgsql;

-- Get full tool chain for a task
CREATE OR REPLACE FUNCTION get_task_toolchain(t_id TEXT)
RETURNS TABLE (
    technique_id TEXT,
    technique_name TEXT,
    tool_id TEXT,
    tool_name TEXT,
    tool_source TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        tech.id as technique_id,
        tech.name as technique_name,
        t.id as tool_id,
        t.name as tool_name,
        t.source as tool_source
    FROM task_technique_map ttm
    JOIN techniques tech ON ttm.technique_id = tech.id
    JOIN tool_technique_map tool_tech ON tech.id = tool_tech.technique_id
    JOIN tools t ON tool_tech.tool_id = t.id
    WHERE ttm.task_id = t_id
    ORDER BY tech.tactic, t.source;
END;
$$ LANGUAGE plpgsql;

-- ─────────────────────────────────────────────────────────────────────────────
-- STATS
-- ─────────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE VIEW v_threat_intel_stats AS
SELECT
    (SELECT COUNT(*) FROM tools) as total_tools,
    (SELECT COUNT(*) FROM techniques) as total_techniques,
    (SELECT COUNT(*) FROM tool_technique_map) as total_mappings,
    (SELECT COUNT(DISTINCT source) FROM tools) as tool_sources,
    (SELECT COUNT(*) FROM tools WHERE source = 'kali') as kali_tools,
    (SELECT COUNT(*) FROM tools WHERE source = 'atomic-red-team') as atomic_tests,
    (SELECT COUNT(*) FROM tools WHERE source = 'nuclei') as nuclei_templates,
    (SELECT COUNT(*) FROM tools WHERE source = 'sigma') as sigma_rules,
    (SELECT COUNT(*) FROM tools WHERE source = 'caldera') as caldera_abilities;

-- ═══════════════════════════════════════════════════════════════════════════
-- DONE
-- ═══════════════════════════════════════════════════════════════════════════
