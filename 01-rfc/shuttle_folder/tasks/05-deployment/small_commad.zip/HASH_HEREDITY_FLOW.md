# Hash Heredity → SmallCommand Flow

## The Question Answered

```
Q: A thing starts with semantic + operational hash.
   We compress two trivariates into Unicode with Lisp operator.
   How do we calculate SmallCommand?

A: HashRef = (lisp-op primary-sch operand)
   where operand encodes secondary/parent/arena relationship
```

---

## Step-by-Step Flow

### 1. Thing Created with Dual Trivariate
```rust
// From trivariate_hash_v731.rs
let primary = engine.generate_trivariate(
    "sensor network alpha",  // semantic content
    "Process",
    "cyber",
    "observe",
    &context,
);
// primary.sch  = "aB7x9pQw2zRt4kMn" → u64: 0xaB7x9pQw...
// primary.cuid = "c5j8k3p2q7w1x9z6" → u64: 0xc5j8k3p2...
// primary.uuid = "550e8400-e29b-..."

let secondary = engine.generate_trivariate(
    "op:aB7x9pQw2zRt4kMn",  // operational hash of primary
    "Process",
    "cyber",
    "observe",
    &op_context,  // inverted delta angle
);
// secondary.sch*  = "xY3z1mNk7qRs2pWv" → u64: 0xY3z1mNk7...
// secondary.cuid* = "d9k2j5n8m3w7x1z4" → u64: 0xd9k2j5n8...
// secondary.uuid* = "661f9511-f39c-..."
```

### 2. Compress to HashRef (16 bytes)
```rust
// Using Lisp CONS operator to pair semantic + operational
let hash_ref = HashRef::cons(
    primary.sch_u64(),       // 0xaB7x9pQw... (8 bytes)
    secondary.sch_u64(),     // 0xY3z1mNk7...
    secondary.cuid_u64(),    // 0xd9k2j5n8...
);

// Result:
// hash_ref.sch = 0xaB7x9pQw...                    (8 bytes)
// hash_ref.heredity = [CONS:8][XOR(sch*,cuid*):56] (8 bytes)
//                   = 0x01_XXXXXXXXXXXX
//                        │  └─ secondary combined
//                        └─ Lisp CONS operator
```

### 3. Encode to Unicode (16 chars)
```rust
let unicode = hash_ref.to_unicode_runes();
// Result: "" (16 PUA chars)
//
// Breakdown:
// [0]:     U+E801 (CONS operator)
// [1-8]:   U+E2xx (SCH as 8 CUID runes)
// [9-15]:  U+E2xx (operand as 7 CUID runes)
```

### 4. Create SmallCommand (64 bytes)
```rust
let cmd = SmallCommand {
    hash_ref,                    // 16 bytes (HashRef replaces TrivariateRef)
    kind: SmallCommandKind::..., // 1 byte
    priority: Priority::Normal,  // 1 byte
    tick_id: 12345,              // 8 bytes
    request_id: 1,               // 4 bytes
    supersession: SupersessionLevel::None, // 1 byte
    flags: 0,                    // 1 byte
    payload: SmallPayload {...}, // 24 bytes
    _pad: [0u8; 8],              // 8 bytes
};
// Total: 64 bytes (1 cache line)
```

### 5. Neural Mux Routing
```rust
// Extract routing info from HashRef
let op = cmd.hash_ref.op();           // CONS
let trigger = cmd.kind.trigger();     // U+E502 (GLAF)
let priority_rune = cmd.priority.to_rune(); // U+E600

// Full routing string
let routing = format!("{}{}{}", 
    trigger,                          // U+E502
    priority_rune,                    // U+E600
    cmd.hash_ref.to_unicode_runes()   // 16 chars
);
// Result: 18-char Unicode string for Neural Mux affinity
```

---

## Memory Layout

```
┌─────────────────────────────────────────────────────────────────┐
│                     SmallCommand (64 bytes)                     │
├─────────────────────────────────────────────────────────────────┤
│ HashRef (16 bytes)                                              │
│ ┌─────────────────────────────────────────────────────────────┐ │
│ │ sch: u64 (8 bytes)                                          │ │
│ │   Primary SCH (semantic identity)                           │ │
│ ├─────────────────────────────────────────────────────────────┤ │
│ │ heredity: u64 (8 bytes)                                     │ │
│ │   [op:8][operand:56]                                        │ │
│ │   ├─ Nil:   operand = CUID packed                          │ │
│ │   ├─ Cons:  operand = XOR(secondary.sch, secondary.cuid)   │ │
│ │   ├─ Ref:   operand = arena_slot | size | checksum         │ │
│ │   └─ Chain: operand = parent_sch_bits | depth              │ │
│ └─────────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────────┤
│ kind: u8          │ priority: u8                                │
├─────────────────────────────────────────────────────────────────┤
│ tick_id: u64                                                    │
├─────────────────────────────────────────────────────────────────┤
│ request_id: u32   │ supersession: u8 │ flags: u8               │
├─────────────────────────────────────────────────────────────────┤
│ payload: SmallPayload (24 bytes)                                │
│   └─ Inline for small ops, ArenaRefPayload for large           │
├─────────────────────────────────────────────────────────────────┤
│ _pad: [u8; 8]                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Lisp Operators Summary

| Op | Char | Meaning | Operand Contents |
|----|------|---------|------------------|
| `nil` | U+E800 | Terminal | CUID packed (56 bits) |
| `cons` | U+E801 | Pair | XOR(sec.sch, sec.cuid) |
| `car` | U+E802 | Primary | Parent ref bits |
| `cdr` | U+E803 | Secondary | Parent ref bits |
| `quote` | U+E804 | Literal | Raw hash bits |
| `ref` | U+E805 | Arena | slot:24 \| size:16 \| csum:16 |
| `derive` | U+E806 | Derived | parent:48 \| delta:8 |
| `xor` | U+E807 | Combined | h2 bits |
| `chain` | U+E808 | Lineage | parent:48 \| depth:8 |
| `supersede` | U+E809 | Replace | old:48 \| level:8 |

---

## Usage Examples

### Terminal Hash (Single Trivariate)
```rust
// Simple case: just semantic hash, no operational
let href = HashRef::terminal(sch, cuid);
// (nil 0xSCH 0xCUID)
```

### Dual Hash (Semantic + Operational)
```rust
// Standard case: both hashes
let href = HashRef::cons(primary_sch, secondary_sch, secondary_cuid);
// (cons 0xPRIMARY 0xXOR_SECONDARY)
```

### Derived Hash (Parent Lineage)
```rust
// New hash derived from parent with delta-angle change
let href = HashRef::derive(new_sch, parent_sch, delta_quantized);
// (derive 0xNEW 0xPARENT|DELTA)
```

### Arena Reference (Large Payload)
```rust
// Matroid with 64 nodes - too big for inline
let href = HashRef::arena_ref(sch, slot_id, size_hint, checksum);
// (ref 0xSCH 0xSLOT|SIZE|CSUM)
```

### Supersession (Delta-Angle Replacement)
```rust
// Old hash superseded at level 3 (Hard)
let href = HashRef::supersede(new_sch, old_sch, SupersessionLevel::Hard as u8);
// (supersede 0xNEW 0xOLD|3)
```

---

## Recovery: From SmallCommand Back to Full Trivariates

```rust
impl SmallCommand {
    /// Recover full hash data (may require arena lookup)
    pub fn recover_hashes(&self, arena: &PayloadArena) -> RecoveredHashes {
        match self.hash_ref.op() {
            HashOp::Nil => {
                // Terminal: reconstruct from CUID
                RecoveredHashes::single(
                    self.hash_ref.sch,
                    self.hash_ref.cuid_packed().unwrap(),
                )
            }
            HashOp::Cons => {
                // Dual: primary known, secondary needs XOR reversal or arena
                RecoveredHashes::dual(
                    self.hash_ref.sch,
                    self.hash_ref.secondary_xor().unwrap(),
                )
            }
            HashOp::Ref => {
                // Arena: full data stored externally
                let slot = self.hash_ref.arena_slot().unwrap();
                arena.get(slot).map(|p| RecoveredHashes::from_payload(p))
                    .unwrap_or_default()
            }
            _ => RecoveredHashes::default(),
        }
    }
}
```

---

## Integration with smart-crate.toml

```toml
# Add to smart-crate.toml

[unicode.heredity]
# Lisp operators for hash heredity (U+E800-E8FF)
nil       = 0xE800
cons      = 0xE801
car       = 0xE802
cdr       = 0xE803
quote     = 0xE804
ref       = 0xE805
derive    = 0xE806
xor       = 0xE807
chain     = 0xE808
supersede = 0xE809
fold      = 0xE80A
lambda    = 0xE80B
apply     = 0xE80C
```

---

## Summary

```
Two Trivariates (96 chars) → HashRef (16 bytes) → SmallCommand (64 bytes)

Compression:
  Primary:   SCH (64 bits) → hash_ref.sch
  Secondary: XOR(SCH*, CUID*) → hash_ref.heredity operand
  Operator:  CONS (8 bits) → hash_ref.heredity high byte

Unicode encoding:
  (cons primary_sch secondary_xor) → 16 PUA runes

Neural Mux routing:
  trigger + priority + hash_runes → affinity matching
```
