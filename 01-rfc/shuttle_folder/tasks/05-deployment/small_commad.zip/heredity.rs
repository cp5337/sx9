//! Hash Heredity - Lisp-style hash relationship encoding
//!
//! Encodes dual trivariate (semantic + operational) relationships
//! into compact 16-byte references using Lisp S-expression operators.
//!
//! # Hash Lineage Model
//! ```text
//! Thing Creation:
//!   Primary (semantic):   SCH  + CUID  + UUID   ─┐
//!   Secondary (operational): SCH* + CUID* + UUID* ─┼─→ HashRef (16 bytes)
//!                                                 │
//!   Lisp operator encodes relationship ───────────┘
//! ```
//!
//! # PUA Block: U+E800-E8FF (Lisp Operators)

use core::fmt;

/// Lisp-style hash operators (U+E800-E8FF)
#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HashOp {
    /// `(nil hash)` - Terminal node, no secondary/parent
    Nil = 0x00,
    
    /// `(cons primary secondary)` - Pair of hashes
    Cons = 0x01,
    
    /// `(car pair)` - Extract primary (semantic)
    Car = 0x02,
    
    /// `(cdr pair)` - Extract secondary (operational)
    Cdr = 0x03,
    
    /// `(quote hash)` - Literal, no evaluation needed
    Quote = 0x04,
    
    /// `(ref slot)` - Arena reference for full data
    Ref = 0x05,
    
    /// `(derive parent delta)` - Derived with delta-angle
    Derive = 0x06,
    
    /// `(xor h1 h2)` - XOR combination of two hashes
    Xor = 0x07,
    
    /// `(chain parent)` - Hash chain link (lineage)
    Chain = 0x08,
    
    /// `(supersede old level)` - Supersession with level
    Supersede = 0x09,
    
    /// `(fold hashes...)` - Merkle-style fold of multiple hashes
    Fold = 0x0A,
    
    /// `(lambda ctx expr)` - Deferred computation
    Lambda = 0x0B,
    
    /// `(apply fn args)` - Apply function to arena args
    Apply = 0x0C,
}

impl HashOp {
    /// Convert to PUA Unicode char (U+E800 base)
    #[inline]
    pub const fn to_char(&self) -> char {
        // Safety: 0xE800 + 0x00-0x0C is always valid Unicode
        unsafe { char::from_u32_unchecked(0xE800 + (*self as u32)) }
    }
    
    /// Parse from PUA Unicode char
    #[inline]
    pub const fn from_char(c: char) -> Option<Self> {
        let code = c as u32;
        if code >= 0xE800 && code <= 0xE80C {
            Some(match (code - 0xE800) as u8 {
                0x00 => Self::Nil,
                0x01 => Self::Cons,
                0x02 => Self::Car,
                0x03 => Self::Cdr,
                0x04 => Self::Quote,
                0x05 => Self::Ref,
                0x06 => Self::Derive,
                0x07 => Self::Xor,
                0x08 => Self::Chain,
                0x09 => Self::Supersede,
                0x0A => Self::Fold,
                0x0B => Self::Lambda,
                0x0C => Self::Apply,
                _ => return None,
            })
        } else {
            None
        }
    }
    
    /// Check if operator requires arena lookup
    #[inline]
    pub const fn requires_arena(&self) -> bool {
        matches!(self, Self::Ref | Self::Apply | Self::Fold)
    }
    
    /// Check if operator has secondary operand
    #[inline]
    pub const fn is_binary(&self) -> bool {
        matches!(self, Self::Cons | Self::Xor | Self::Derive | Self::Supersede)
    }
}

/// Hash reference with Lisp-style heredity encoding
/// 
/// # Memory Layout (16 bytes)
/// ```text
/// ┌─────────────────────────────────────────────────────────────┐
/// │ sch: u64 (8 bytes)                                          │
/// │   Primary SCH hash (Murmur3-128 lower 64 bits)             │
/// ├─────────────────────────────────────────────────────────────┤
/// │ heredity: u64 (8 bytes)                                     │
/// │   [op:8][operand:56]                                        │
/// │   op: HashOp discriminant                                   │
/// │   operand: interpretation depends on op                     │
/// └─────────────────────────────────────────────────────────────┘
/// ```
/// 
/// # Operand Interpretations
/// - `Nil`:       operand = packed CUID (timestamp|env|agent|delta|state)
/// - `Cons`:      operand = XOR(secondary.sch, secondary.cuid) 
/// - `Car/Cdr`:   operand = parent HashRef bits
/// - `Ref`:       operand = arena_slot:24 | size_hint:16 | checksum:16
/// - `Derive`:    operand = parent_sch:48 | delta_angle:8
/// - `Chain`:     operand = parent_sch:48 | chain_depth:8
/// - `Supersede`: operand = old_sch:48 | level:8
#[repr(C)]
#[derive(Clone, Copy, PartialEq, Eq, Hash)]
pub struct HashRef {
    /// Primary SCH hash (semantic content hash)
    pub sch: u64,
    
    /// Heredity encoding: [op:8][operand:56]
    pub heredity: u64,
}

impl HashRef {
    /// Create empty/null reference
    pub const fn null() -> Self {
        Self { sch: 0, heredity: 0 }
    }
    
    /// Create terminal hash (no secondary, no parent)
    /// `(nil sch cuid)`
    pub const fn terminal(sch: u64, cuid_packed: u64) -> Self {
        // Ensure CUID fits in 56 bits (should always be true)
        let operand = cuid_packed & 0x00FF_FFFF_FFFF_FFFF;
        Self {
            sch,
            heredity: ((HashOp::Nil as u64) << 56) | operand,
        }
    }
    
    /// Create cons cell (semantic . operational)
    /// `(cons primary secondary)`
    /// 
    /// Compresses secondary trivariate into operand via XOR
    pub const fn cons(primary_sch: u64, secondary_sch: u64, secondary_cuid: u64) -> Self {
        // XOR secondary components for compact encoding
        let combined = (secondary_sch ^ secondary_cuid) & 0x00FF_FFFF_FFFF_FFFF;
        Self {
            sch: primary_sch,
            heredity: ((HashOp::Cons as u64) << 56) | combined,
        }
    }
    
    /// Create arena reference for large payloads
    /// `(ref slot size checksum)`
    pub const fn arena_ref(sch: u64, slot: u32, size_hint: u16, checksum: u16) -> Self {
        let operand = ((slot as u64) << 32) | ((size_hint as u64) << 16) | (checksum as u64);
        Self {
            sch,
            heredity: ((HashOp::Ref as u64) << 56) | operand,
        }
    }
    
    /// Create derived hash with delta-angle
    /// `(derive parent delta)`
    pub const fn derive(derived_sch: u64, parent_sch: u64, delta_quantized: u8) -> Self {
        let parent_bits = (parent_sch >> 16) & 0x00FF_FFFF_FFFF_FF00;
        let operand = parent_bits | (delta_quantized as u64);
        Self {
            sch: derived_sch,
            heredity: ((HashOp::Derive as u64) << 56) | operand,
        }
    }
    
    /// Create hash chain link
    /// `(chain parent depth)`
    pub const fn chain(sch: u64, parent_sch: u64, depth: u8) -> Self {
        let parent_bits = (parent_sch >> 16) & 0x00FF_FFFF_FFFF_FF00;
        let operand = parent_bits | (depth as u64);
        Self {
            sch,
            heredity: ((HashOp::Chain as u64) << 56) | operand,
        }
    }
    
    /// Create supersession reference
    /// `(supersede old level)`
    pub const fn supersede(new_sch: u64, old_sch: u64, level: u8) -> Self {
        let old_bits = (old_sch >> 16) & 0x00FF_FFFF_FFFF_FF00;
        let operand = old_bits | (level as u64);
        Self {
            sch: new_sch,
            heredity: ((HashOp::Supersede as u64) << 56) | operand,
        }
    }
    
    /// Create XOR combination of two hashes
    /// `(xor h1 h2)`
    pub const fn xor(h1_sch: u64, h2_sch: u64) -> Self {
        let combined_sch = h1_sch ^ h2_sch;
        let operand = h2_sch & 0x00FF_FFFF_FFFF_FFFF;
        Self {
            sch: combined_sch,
            heredity: ((HashOp::Xor as u64) << 56) | operand,
        }
    }
    
    // === Accessors ===
    
    /// Get the Lisp operator
    #[inline]
    pub const fn op(&self) -> HashOp {
        match (self.heredity >> 56) as u8 {
            0x00 => HashOp::Nil,
            0x01 => HashOp::Cons,
            0x02 => HashOp::Car,
            0x03 => HashOp::Cdr,
            0x04 => HashOp::Quote,
            0x05 => HashOp::Ref,
            0x06 => HashOp::Derive,
            0x07 => HashOp::Xor,
            0x08 => HashOp::Chain,
            0x09 => HashOp::Supersede,
            0x0A => HashOp::Fold,
            0x0B => HashOp::Lambda,
            0x0C => HashOp::Apply,
            _ => HashOp::Nil, // Default fallback
        }
    }
    
    /// Get the operand (lower 56 bits)
    #[inline]
    pub const fn operand(&self) -> u64 {
        self.heredity & 0x00FF_FFFF_FFFF_FFFF
    }
    
    /// Check if this requires arena lookup
    #[inline]
    pub const fn requires_arena(&self) -> bool {
        self.op().requires_arena()
    }
    
    /// Check if this is a dual hash (cons cell)
    #[inline]
    pub const fn is_dual(&self) -> bool {
        matches!(self.op(), HashOp::Cons)
    }
    
    /// Check if this is a terminal node
    #[inline]
    pub const fn is_terminal(&self) -> bool {
        matches!(self.op(), HashOp::Nil | HashOp::Quote)
    }
    
    // === Extraction (for cons cells) ===
    
    /// Extract CUID packed value (for Nil/terminal)
    #[inline]
    pub const fn cuid_packed(&self) -> Option<u64> {
        if matches!(self.op(), HashOp::Nil) {
            Some(self.operand())
        } else {
            None
        }
    }
    
    /// Extract secondary hash XOR (for Cons)
    #[inline]
    pub const fn secondary_xor(&self) -> Option<u64> {
        if matches!(self.op(), HashOp::Cons) {
            Some(self.operand())
        } else {
            None
        }
    }
    
    /// Extract arena slot (for Ref)
    #[inline]
    pub const fn arena_slot(&self) -> Option<u32> {
        if matches!(self.op(), HashOp::Ref) {
            Some((self.operand() >> 32) as u32)
        } else {
            None
        }
    }
    
    /// Extract parent hash bits (for Derive/Chain/Supersede)
    #[inline]
    pub const fn parent_bits(&self) -> Option<u64> {
        match self.op() {
            HashOp::Derive | HashOp::Chain | HashOp::Supersede => {
                Some((self.operand() & 0x00FF_FFFF_FFFF_FF00) << 16)
            }
            _ => None,
        }
    }
    
    /// Extract delta/depth/level byte (last byte of operand)
    #[inline]
    pub const fn meta_byte(&self) -> u8 {
        (self.operand() & 0xFF) as u8
    }
    
    // === Unicode Encoding ===
    
    /// Encode to Unicode string (Lisp S-expression style)
    /// Format: `(op sch operand)`
    pub fn to_lisp_string(&self) -> String {
        let op_char = self.op().to_char();
        format!("({} {:016x} {:014x})", op_char, self.sch, self.operand())
    }
    
    /// Encode to compact Unicode runes
    /// [op_rune][sch_runes:8][operand_runes:7]
    pub fn to_unicode_runes(&self) -> String {
        let mut s = String::with_capacity(16);
        
        // Operator rune (U+E800-E8FF)
        s.push(self.op().to_char());
        
        // SCH as 8 runes (U+E200-E2FF)
        for b in self.sch.to_be_bytes() {
            s.push(crate::unicode::cuid::encode_byte(b));
        }
        
        // Operand as 7 runes (56 bits = 7 bytes)
        let operand_bytes = self.operand().to_be_bytes();
        for b in &operand_bytes[1..8] { // Skip high byte (already in op)
            s.push(crate::unicode::cuid::encode_byte(*b));
        }
        
        s
    }
}

impl Default for HashRef {
    fn default() -> Self {
        Self::null()
    }
}

impl fmt::Debug for HashRef {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "HashRef({:?} {:016x} {:014x})", 
            self.op(), self.sch, self.operand())
    }
}

impl fmt::Display for HashRef {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.to_lisp_string())
    }
}

/// Builder for constructing hash heredity from dual trivariates
pub struct HashRefBuilder {
    primary_sch: u64,
    primary_cuid: u64,
    secondary_sch: Option<u64>,
    secondary_cuid: Option<u64>,
    parent: Option<u64>,
    delta_angle: Option<f32>,
}

impl HashRefBuilder {
    /// Start with primary (semantic) hash
    pub fn new(sch: u64, cuid: u64) -> Self {
        Self {
            primary_sch: sch,
            primary_cuid: cuid,
            secondary_sch: None,
            secondary_cuid: None,
            parent: None,
            delta_angle: None,
        }
    }
    
    /// Add secondary (operational) hash
    pub fn with_secondary(mut self, sch: u64, cuid: u64) -> Self {
        self.secondary_sch = Some(sch);
        self.secondary_cuid = Some(cuid);
        self
    }
    
    /// Add parent lineage
    pub fn with_parent(mut self, parent_sch: u64) -> Self {
        self.parent = Some(parent_sch);
        self
    }
    
    /// Add delta-angle for derivation
    pub fn with_delta(mut self, delta: f32) -> Self {
        self.delta_angle = Some(delta);
        self
    }
    
    /// Build the HashRef
    pub fn build(self) -> HashRef {
        // Case 1: Has parent with delta - derivation
        if let (Some(parent), Some(delta)) = (self.parent, self.delta_angle) {
            let delta_quantized = ((delta.abs() * 6.0) as u8).min(255);
            return HashRef::derive(self.primary_sch, parent, delta_quantized);
        }
        
        // Case 2: Has parent without delta - chain
        if let Some(parent) = self.parent {
            return HashRef::chain(self.primary_sch, parent, 1);
        }
        
        // Case 3: Has secondary - cons cell
        if let (Some(sec_sch), Some(sec_cuid)) = (self.secondary_sch, self.secondary_cuid) {
            return HashRef::cons(self.primary_sch, sec_sch, sec_cuid);
        }
        
        // Case 4: Terminal - just primary
        HashRef::terminal(self.primary_sch, self.primary_cuid)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_hash_ref_size() {
        assert_eq!(core::mem::size_of::<HashRef>(), 16);
    }
    
    #[test]
    fn test_terminal() {
        let cuid = 0x0012_3456_789A_BCDE_u64;
        let href = HashRef::terminal(0xDEAD_BEEF, cuid);
        
        assert_eq!(href.op(), HashOp::Nil);
        assert_eq!(href.sch, 0xDEAD_BEEF);
        assert_eq!(href.cuid_packed(), Some(cuid & 0x00FF_FFFF_FFFF_FFFF));
        assert!(href.is_terminal());
        assert!(!href.is_dual());
    }
    
    #[test]
    fn test_cons_cell() {
        let href = HashRef::cons(
            0xAAAA_BBBB, // primary SCH
            0xCCCC_DDDD, // secondary SCH
            0xEEEE_FFFF, // secondary CUID
        );
        
        assert_eq!(href.op(), HashOp::Cons);
        assert_eq!(href.sch, 0xAAAA_BBBB);
        assert!(href.is_dual());
        
        // Secondary XOR should be (sec_sch ^ sec_cuid) masked
        let expected_xor = (0xCCCC_DDDD_u64 ^ 0xEEEE_FFFF_u64) & 0x00FF_FFFF_FFFF_FFFF;
        assert_eq!(href.secondary_xor(), Some(expected_xor));
    }
    
    #[test]
    fn test_arena_ref() {
        let href = HashRef::arena_ref(0x1234, 42, 256, 0xABCD);
        
        assert_eq!(href.op(), HashOp::Ref);
        assert!(href.requires_arena());
        assert_eq!(href.arena_slot(), Some(42));
    }
    
    #[test]
    fn test_derive() {
        let href = HashRef::derive(
            0xNEW_HASH, // derived
            0xPARENT,   // parent
            42,         // delta quantized
        );
        
        assert_eq!(href.op(), HashOp::Derive);
        assert_eq!(href.meta_byte(), 42);
    }
    
    #[test]
    fn test_builder() {
        // Terminal
        let terminal = HashRefBuilder::new(0xAAAA, 0xBBBB).build();
        assert!(terminal.is_terminal());
        
        // Dual
        let dual = HashRefBuilder::new(0xAAAA, 0xBBBB)
            .with_secondary(0xCCCC, 0xDDDD)
            .build();
        assert!(dual.is_dual());
        
        // Derived
        let derived = HashRefBuilder::new(0xAAAA, 0xBBBB)
            .with_parent(0xPARENT)
            .with_delta(15.0)
            .build();
        assert_eq!(derived.op(), HashOp::Derive);
    }
    
    #[test]
    fn test_lisp_string() {
        let href = HashRef::terminal(0xDEAD_BEEF, 0x1234);
        let s = href.to_lisp_string();
        assert!(s.starts_with('('));
        assert!(s.contains("deadbeef"));
    }
    
    #[test]
    fn test_unicode_runes() {
        let href = HashRef::cons(0xAAAA, 0xBBBB, 0xCCCC);
        let runes = href.to_unicode_runes();
        
        // Should be 16 chars: 1 op + 8 sch + 7 operand
        assert_eq!(runes.chars().count(), 16);
        
        // First char should be Cons operator (U+E801)
        assert_eq!(runes.chars().next().unwrap() as u32, 0xE801);
    }
}
