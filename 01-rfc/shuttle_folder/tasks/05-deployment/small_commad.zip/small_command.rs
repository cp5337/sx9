//! SmallCommand - Cache-line aligned command for HFT performance
//!
//! 64 bytes total (1 cache line) with HashRef for hash heredity.
//! Large payloads stored in arena, referenced by Lisp-style hash operators.
//!
//! # Hash Heredity
//! Commands carry `HashRef` which encodes:
//! - Primary SCH (semantic identity)
//! - Lisp operator (nil/cons/ref/derive/etc.)
//! - Operand (secondary hash XOR, arena slot, parent bits, etc.)

use crate::unicode::{self, SupersessionLevel};
use crate::heredity::{HashRef, HashOp};
use core::mem::size_of;

// Compile-time size assertions
const _: () = assert!(size_of::<SmallCommand>() == 64);
const _: () = assert!(size_of::<HashRef>() == 16);
const _: () = assert!(size_of::<SmallPayload>() == 24);

/// Priority levels for command routing
#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Priority {
    Normal = 0,
    Urgent = 1,
    Critical = 2,
}

impl Priority {
    /// Convert to Unicode priority rune
    #[inline]
    pub const fn to_rune(&self) -> char {
        unicode::priority::encode(*self as u8)
    }
}

/// SmallCommand kind discriminant
#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SmallCommandKind {
    // Graph operations (0-2)
    Dijkstra = 0,
    Bfs = 1,
    AllPaths = 2,
    
    // Matroid operations (3-5) - payload in arena
    MatroidRank = 3,
    MatroidIndependent = 4,
    MaxIndependentSet = 5,
    
    // Convergence operations (6-7)
    ConvergenceCheck = 6,
    ConvergenceRate = 7,
    
    // Hash operations (8-10)
    BatchHash = 8,
    TrivariateHash = 9,
    HashLookup = 10,
    
    // Tick operations (11-12)
    TickSync = 11,
    TickQuery = 12,
    
    // SDT operations (13-15)
    SdtTrigger = 13,
    SdtReset = 14,
    SdtQuery = 15,
    
    // Plasma operations (16-17)
    PlasmaUpdate = 16,
    PlasmaQuery = 17,
    
    // Control operations (18-20)
    Ping = 18,
    Shutdown = 19,
    Stats = 20,
}

impl SmallCommandKind {
    /// Get Unicode trigger for Neural Mux routing
    #[inline]
    pub const fn trigger(&self) -> char {
        unicode::triggers::from_kind(*self as u8)
    }
    
    /// Check if payload is inline (true) or in arena (false)
    #[inline]
    pub const fn is_inline(&self) -> bool {
        match self {
            Self::MatroidRank | Self::MatroidIndependent | Self::MaxIndependentSet |
            Self::BatchHash | Self::AllPaths => false,
            _ => true,
        }
    }
}

/// Inline payload union (24 bytes max)
#[repr(C)]
#[derive(Clone, Copy)]
pub union SmallPayload {
    // Graph operations
    pub dijkstra: DijkstraPayload,
    pub bfs: BfsPayload,
    
    // Convergence
    pub conv_check: ConvergenceCheckPayload,
    pub conv_rate: ConvergenceRatePayload,
    
    // Tick operations
    pub tick_sync: TickSyncPayload,
    
    // SDT operations
    pub sdt_trigger: SdtTriggerPayload,
    pub sdt_reset: SdtResetPayload,
    pub sdt_query: SdtQueryPayload,
    
    // Plasma operations
    pub plasma_update: PlasmaUpdatePayload,
    pub plasma_query: PlasmaQueryPayload,
    
    // Control operations
    pub ping: PingPayload,
    
    // Arena reference (for large payloads)
    pub arena_ref: ArenaRefPayload,
    
    // Raw bytes
    pub raw: [u8; 24],
}

impl Default for SmallPayload {
    fn default() -> Self {
        Self { raw: [0u8; 24] }
    }
}

// Payload structures (all must be <= 24 bytes)

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct DijkstraPayload {
    pub src: u32,
    pub dst: u32,
    pub max_hops: u8,
    pub _pad: [u8; 15],
}

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct BfsPayload {
    pub src: u32,
    pub max_depth: u8,
    pub _pad: [u8; 19],
}

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct ConvergenceCheckPayload {
    pub entity_id: u32,
    pub epsilon: f32,
    pub window: u16,
    pub _pad: [u8; 14],
}

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct ConvergenceRatePayload {
    pub entity_id: u32,
    pub window: u16,
    pub _pad: [u8; 18],
}

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct TickSyncPayload {
    pub tick_id: u64,
    pub timestamp_ns: u64,
    pub _pad: [u8; 8],
}

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct SdtTriggerPayload {
    pub gate_id: u32,
    pub reason: u16,
    pub _pad: [u8; 18],
}

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct SdtResetPayload {
    pub gate_id: u32,
    pub _pad: [u8; 20],
}

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct SdtQueryPayload {
    pub gate_id: u32,
    pub _pad: [u8; 20],
}

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct PlasmaUpdatePayload {
    pub field_id: u32,
    pub delta_angle: u16,
    pub entropy: u32,
    pub excited: u8,
    pub _pad: [u8; 13],
}

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct PlasmaQueryPayload {
    pub field_id: u32,
    pub _pad: [u8; 20],
}

#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct PingPayload {
    pub seq: u32,
    pub timestamp_ns: u64,
    pub _pad: [u8; 12],
}

/// Arena reference for large payloads
#[repr(C)]
#[derive(Clone, Copy, Debug)]
pub struct ArenaRefPayload {
    /// Arena slot index
    pub slot: u32,
    /// Payload size hint
    pub size_hint: u32,
    /// Checksum for integrity
    pub checksum: u64,
    pub _pad: [u8; 8],
}

/// Cache-line aligned SmallCommand (64 bytes)
#[repr(C, align(64))]
#[derive(Clone, Copy)]
pub struct SmallCommand {
    /// Hash heredity reference (primary SCH + Lisp-encoded relationship)
    pub hash_ref: HashRef,           // 16 bytes
    
    /// Command kind discriminant
    pub kind: SmallCommandKind,      // 1 byte
    
    /// Priority level
    pub priority: Priority,          // 1 byte
    
    /// Tick ID when created
    pub tick_id: u64,                // 8 bytes
    
    /// Request ID for correlation
    pub request_id: u32,             // 4 bytes
    
    /// Supersession level (delta-angle)
    pub supersession: SupersessionLevel, // 1 byte
    
    /// Reserved flags
    pub flags: u8,                   // 1 byte
    
    /// Inline payload (or arena reference)
    pub payload: SmallPayload,       // 24 bytes
    
    /// Padding to 64 bytes
    _pad: [u8; 8],                   // 8 bytes
}

impl SmallCommand {
    /// Create new command with default values
    pub fn new(kind: SmallCommandKind) -> Self {
        Self {
            hash_ref: HashRef::null(),
            kind,
            priority: Priority::Normal,
            tick_id: 0,
            request_id: 0,
            supersession: SupersessionLevel::None,
            flags: 0,
            payload: SmallPayload::default(),
            _pad: [0u8; 8],
        }
    }
    
    /// Create with priority
    pub fn with_priority(kind: SmallCommandKind, priority: Priority) -> Self {
        let mut cmd = Self::new(kind);
        cmd.priority = priority;
        cmd
    }
    
    /// Create critical command
    pub fn critical(kind: SmallCommandKind) -> Self {
        Self::with_priority(kind, Priority::Critical)
    }
    
    /// Create urgent command
    pub fn urgent(kind: SmallCommandKind) -> Self {
        Self::with_priority(kind, Priority::Urgent)
    }
    
    /// Set hash reference (terminal - single trivariate)
    pub fn with_hash(mut self, sch: u64, cuid: u64) -> Self {
        self.hash_ref = HashRef::terminal(sch, cuid);
        self
    }
    
    /// Set hash reference (dual - semantic + operational)
    pub fn with_dual_hash(mut self, primary_sch: u64, secondary_sch: u64, secondary_cuid: u64) -> Self {
        self.hash_ref = HashRef::cons(primary_sch, secondary_sch, secondary_cuid);
        self
    }
    
    /// Set hash reference (derived from parent)
    pub fn with_derived_hash(mut self, sch: u64, parent_sch: u64, delta: f32) -> Self {
        let delta_quantized = ((delta.abs() * 6.0) as u8).min(255);
        self.hash_ref = HashRef::derive(sch, parent_sch, delta_quantized);
        self
    }
    
    /// Set hash reference directly
    pub fn with_hash_ref(mut self, hash_ref: HashRef) -> Self {
        self.hash_ref = hash_ref;
        self
    }
    
    /// Set tick ID
    pub fn with_tick(mut self, tick_id: u64) -> Self {
        self.tick_id = tick_id;
        self
    }
    
    /// Set request ID
    pub fn with_request_id(mut self, request_id: u32) -> Self {
        self.request_id = request_id;
        self
    }
    
    /// Set supersession level
    pub fn with_supersession(mut self, level: SupersessionLevel) -> Self {
        self.supersession = level;
        self
    }
    
    /// Get Unicode trigger for routing
    #[inline]
    pub fn trigger(&self) -> char {
        self.kind.trigger()
    }
    
    /// Get Lisp operator from hash heredity
    #[inline]
    pub fn hash_op(&self) -> HashOp {
        self.hash_ref.op()
    }
    
    /// Check if payload is inline
    #[inline]
    pub fn is_inline(&self) -> bool {
        self.kind.is_inline() && !self.hash_ref.requires_arena()
    }
    
    /// Check if this is a dual hash (semantic + operational)
    #[inline]
    pub fn is_dual(&self) -> bool {
        self.hash_ref.is_dual()
    }
    
    /// Get Unicode routing string for Neural Mux
    /// Format: [trigger][priority][op][sch_runes][operand_runes]
    pub fn to_routing_string(&self, domain: char) -> String {
        let mut s = String::with_capacity(20);
        s.push(self.trigger());
        s.push(self.priority.to_rune());
        s.push(domain);
        s.push_str(&self.hash_ref.to_unicode_runes());
        s
    }
    
    /// Get Lisp-style representation
    pub fn to_lisp_string(&self) -> String {
        format!("(cmd {:?} {})", self.kind, self.hash_ref.to_lisp_string())
    }
    
    // Builder methods for specific commands
    
    /// Create Dijkstra command
    pub fn dijkstra(src: u32, dst: u32, max_hops: u8) -> Self {
        let mut cmd = Self::new(SmallCommandKind::Dijkstra);
        cmd.payload = SmallPayload {
            dijkstra: DijkstraPayload {
                src,
                dst,
                max_hops,
                _pad: [0u8; 15],
            },
        };
        cmd
    }
    
    /// Create BFS command
    pub fn bfs(src: u32, max_depth: u8) -> Self {
        let mut cmd = Self::new(SmallCommandKind::Bfs);
        cmd.payload = SmallPayload {
            bfs: BfsPayload {
                src,
                max_depth,
                _pad: [0u8; 19],
            },
        };
        cmd
    }
    
    /// Create Ping command
    pub fn ping(seq: u32, timestamp_ns: u64) -> Self {
        let mut cmd = Self::new(SmallCommandKind::Ping);
        cmd.payload = SmallPayload {
            ping: PingPayload {
                seq,
                timestamp_ns,
                _pad: [0u8; 12],
            },
        };
        cmd
    }
    
    /// Create TickSync command
    pub fn tick_sync(tick_id: u64, timestamp_ns: u64) -> Self {
        let mut cmd = Self::new(SmallCommandKind::TickSync);
        cmd.payload = SmallPayload {
            tick_sync: TickSyncPayload {
                tick_id,
                timestamp_ns,
                _pad: [0u8; 8],
            },
        };
        cmd
    }
    
    /// Create SDT trigger command
    pub fn sdt_trigger(gate_id: u32, reason: u16) -> Self {
        let mut cmd = Self::critical(SmallCommandKind::SdtTrigger);
        cmd.payload = SmallPayload {
            sdt_trigger: SdtTriggerPayload {
                gate_id,
                reason,
                _pad: [0u8; 18],
            },
        };
        cmd
    }
    
    /// Create convergence check command
    pub fn convergence_check(entity_id: u32, epsilon: f32, window: u16) -> Self {
        let mut cmd = Self::new(SmallCommandKind::ConvergenceCheck);
        cmd.payload = SmallPayload {
            conv_check: ConvergenceCheckPayload {
                entity_id,
                epsilon,
                window,
                _pad: [0u8; 14],
            },
        };
        cmd
    }
    
    /// Create matroid rank command (payload in arena)
    pub fn matroid_rank(arena_slot: u32, node_count: u32, checksum: u64) -> Self {
        let mut cmd = Self::new(SmallCommandKind::MatroidRank);
        cmd.payload = SmallPayload {
            arena_ref: ArenaRefPayload {
                slot: arena_slot,
                size_hint: node_count * 4, // u32 per node
                checksum,
                _pad: [0u8; 8],
            },
        };
        cmd
    }
    
    /// Create shutdown command
    pub fn shutdown() -> Self {
        Self::critical(SmallCommandKind::Shutdown)
    }
    
    /// Create stats request command
    pub fn stats() -> Self {
        Self::new(SmallCommandKind::Stats)
    }
}

impl core::fmt::Debug for SmallCommand {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("SmallCommand")
            .field("kind", &self.kind)
            .field("priority", &self.priority)
            .field("tick_id", &self.tick_id)
            .field("request_id", &self.request_id)
            .field("supersession", &self.supersession)
            .field("hash_op", &self.hash_ref.op())
            .field("sch", &format!("{:016x}", self.hash_ref.sch))
            .finish()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_small_command_size() {
        assert_eq!(size_of::<SmallCommand>(), 64, "SmallCommand must be 64 bytes");
    }
    
    #[test]
    fn test_payload_size() {
        assert_eq!(size_of::<SmallPayload>(), 24, "SmallPayload must be 24 bytes");
    }
    
    #[test]
    fn test_dijkstra_command() {
        let cmd = SmallCommand::dijkstra(1, 42, 10);
        assert_eq!(cmd.kind, SmallCommandKind::Dijkstra);
        assert!(cmd.is_inline());
        
        unsafe {
            assert_eq!(cmd.payload.dijkstra.src, 1);
            assert_eq!(cmd.payload.dijkstra.dst, 42);
            assert_eq!(cmd.payload.dijkstra.max_hops, 10);
        }
    }
    
    #[test]
    fn test_matroid_arena_ref() {
        let cmd = SmallCommand::matroid_rank(5, 64, 0xDEADBEEF);
        assert_eq!(cmd.kind, SmallCommandKind::MatroidRank);
        assert!(!cmd.is_inline());
        
        unsafe {
            assert_eq!(cmd.payload.arena_ref.slot, 5);
            assert_eq!(cmd.payload.arena_ref.size_hint, 256);
            assert_eq!(cmd.payload.arena_ref.checksum, 0xDEADBEEF);
        }
    }
    
    #[test]
    fn test_hash_heredity() {
        // Terminal (single trivariate)
        let cmd = SmallCommand::dijkstra(1, 42, 10)
            .with_hash(0xDEAD_BEEF, 0x1234_5678);
        
        assert_eq!(cmd.hash_ref.op(), HashOp::Nil);
        assert_eq!(cmd.hash_ref.sch, 0xDEAD_BEEF);
        assert!(!cmd.is_dual());
        
        // Dual (semantic + operational)
        let dual_cmd = SmallCommand::ping(1, 0)
            .with_dual_hash(0xAAAA, 0xBBBB, 0xCCCC);
        
        assert_eq!(dual_cmd.hash_ref.op(), HashOp::Cons);
        assert!(dual_cmd.is_dual());
    }
    
    #[test]
    fn test_derived_hash() {
        let cmd = SmallCommand::convergence_check(1, 0.01, 10)
            .with_derived_hash(0xNEW, 0xPARENT, 15.0);
        
        assert_eq!(cmd.hash_ref.op(), HashOp::Derive);
        // delta 15.0 * 6 = 90, within u8
        assert_eq!(cmd.hash_ref.meta_byte(), 90);
    }
    
    #[test]
    fn test_routing_string() {
        let cmd = SmallCommand::dijkstra(1, 42, 10)
            .with_hash(0xDEAD_BEEF, 0x1234_5678);
        
        let routing = cmd.to_routing_string(unicode::domain::CYBER);
        
        // Verify routing string starts with correct trigger
        assert_eq!(
            routing.chars().next().unwrap(),
            unicode::triggers::GLAF_MATROID
        );
    }
    
    #[test]
    fn test_lisp_string() {
        let cmd = SmallCommand::ping(42, 1234567890)
            .with_dual_hash(0xAAAA, 0xBBBB, 0xCCCC);
        
        let lisp = cmd.to_lisp_string();
        assert!(lisp.starts_with("(cmd"));
        assert!(lisp.contains("Ping"));
    }
    
    #[test]
    fn test_priority_commands() {
        let normal = SmallCommand::ping(1, 0);
        let urgent = SmallCommand::urgent(SmallCommandKind::Ping);
        let critical = SmallCommand::sdt_trigger(0, 1);
        
        assert_eq!(normal.priority, Priority::Normal);
        assert_eq!(urgent.priority, Priority::Urgent);
        assert_eq!(critical.priority, Priority::Critical);
    }
}
