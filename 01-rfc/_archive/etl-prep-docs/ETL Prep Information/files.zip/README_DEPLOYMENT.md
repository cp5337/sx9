# 🚀 RFC-9005 Complete Backend Deployment Guide

**One-Command Backend Stack Deployment**

---

## 🎯 **WHAT YOU GET**

A complete, RFC-9005 compliant backend with:

- ✅ Neo4j (GLAF graph database)
- ✅ Redis/Sledis (cache)
- ✅ ChromaDB (vector search)
- ✅ PostgreSQL (local dev)
- ✅ PgAdmin (database UI)
- ✅ All schemas pre-loaded
- ✅ RFC-9001/9002 hash validation
- ✅ Zero SHA contamination

**Cost:** $0 (all local)

---

## 🚀 **QUICK START (3 Commands)**

```bash
# 1. Copy files to your project
cd ~/Developer/ctas-7-shipyard-staging/04-abe-iac
# (Copy all files here)

# 2. Configure environment
cp .env.example .env
# Edit .env with your Supabase and Neon credentials

# 3. Deploy everything!
./deploy_backend.sh
```

**Done!** Your entire backend is running. ✅

---

## 📋 **FILES**

```
04-abe-iac/
├── docker-compose.yml          # Complete backend stack
├── .env.example                # Configuration template
├── .env                        # Your config (create this)
├── deploy_backend.sh           # One-command deployment
├── rfc9005_unified_loader.py   # Data loader
├── neon_schema.sql             # PostgreSQL schema
├── neo4j_schema.cypher         # Neo4j schema
└── README_DEPLOYMENT.md        # This file
```

---

## ⚙️ **DETAILED SETUP**

### **Step 1: Prerequisites**

```bash
# Install Docker OR OrbStack
# macOS:
brew install orbstack
# OR
brew install docker

# Verify
docker --version
```

### **Step 2: Get Your Cloud Credentials**

#### **Supabase (Required)**

1. Go to https://supabase.com/dashboard
2. Select your project
3. Go to Settings → API
4. Copy:
   - **URL:** `https://xxx.supabase.co`
   - **anon public key:** `eyJhbG...`

#### **Neon (Optional but Recommended)**

1. Go to https://console.neon.tech
2. Create project (free tier)
3. Copy connection string:
   - `postgres://user:pass@host.neon.tech/dbname`

### **Step 3: Configure Environment**

```bash
cd ~/Developer/ctas-7-shipyard-staging/04-abe-iac

# Copy template
cp .env.example .env

# Edit with your values
nano .env  # or vim, code, etc.
```

**Required values:**
```bash
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your-anon-key-here
```

**Optional but recommended:**
```bash
NEON_DATABASE_URL=postgres://user:pass@host.neon.tech/dbname
```

### **Step 4: Deploy**

```bash
./deploy_backend.sh
```

This script will:
1. ✅ Start all Docker containers
2. ✅ Wait for services to be healthy
3. ✅ Initialize Neo4j schema
4. ✅ Initialize PostgreSQL schema
5. ✅ Load threat intelligence data
6. ✅ Validate RFC compliance
7. ✅ Print summary

**Time:** 2-3 minutes

---

## 🔍 **VERIFY DEPLOYMENT**

### **Check Services**

```bash
docker compose ps
```

Should show all services as "healthy":
```
NAME              STATUS
ctas7-neo4j       Up (healthy)
ctas7-sledis      Up (healthy)
ctas7-chromadb    Up (healthy)
ctas7-postgres    Up (healthy)
```

### **Check Neo4j**

Open browser: http://localhost:7474

Login:
- **Username:** neo4j
- **Password:** ctas7-password-change-me

Run query:
```cypher
MATCH (t:Tool)
RETURN count(t) as total_tools;
```

### **Check PostgreSQL**

```bash
docker compose exec postgres psql -U ctas7 -d ctas7_dev -c "SELECT count(*) FROM tool_registry;"
```

### **Check RFC Compliance**

```bash
# Verify NO SHA contamination (should return 0)
docker compose exec neo4j cypher-shell -u neo4j -p ctas7-password-change-me \
  "MATCH (n) WHERE n.genome IS NOT NULL AND size(n.genome) <> 16 RETURN count(n)"
```

---

## 🎛️ **MANAGING SERVICES**

### **Start All**
```bash
docker compose up -d
```

### **Stop All**
```bash
docker compose down
```

### **View Logs**
```bash
docker compose logs -f neo4j
docker compose logs -f redis
```

### **Restart Single Service**
```bash
docker compose restart neo4j
```

### **Delete All Data (Fresh Start)**
```bash
docker compose down -v  # WARNING: Deletes all data!
```

---

## 🔧 **MANUAL OPERATIONS**

### **Re-run Data Loader**

```bash
python3 rfc9005_unified_loader.py --threat-content ./node-interview-generator/output/threat_content
```

### **Load Additional Sources**

```bash
# After fetching MITRE, Sigma, etc.
python3 rfc9005_unified_loader.py --source mitre
python3 rfc9005_unified_loader.py --source sigma
```

### **Access Neo4j Shell**

```bash
docker compose exec neo4j cypher-shell -u neo4j -p ctas7-password-change-me
```

### **Access PostgreSQL Shell**

```bash
docker compose exec postgres psql -U ctas7 -d ctas7_dev
```

### **Access Redis CLI**

```bash
docker compose exec redis redis-cli
```

---

## 📊 **DATABASE ACCESS**

| Service | URL/Connection | Credentials |
|---------|---------------|-------------|
| **Neo4j Browser** | http://localhost:7474 | neo4j / ctas7-password-change-me |
| **Neo4j Bolt** | bolt://localhost:7687 | neo4j / ctas7-password-change-me |
| **PgAdmin** | http://localhost:5050 | admin@ctas7.local / admin |
| **PostgreSQL** | localhost:5432 | ctas7 / ctas7-dev-password |
| **Redis** | localhost:6379 | (no auth) |
| **ChromaDB** | http://localhost:8000 | (no auth) |

---

## 🐛 **TROUBLESHOOTING**

### **"Port already in use"**

```bash
# Check what's using the port
lsof -i :7687  # Neo4j
lsof -i :6379  # Redis
lsof -i :5432  # PostgreSQL

# Kill or change port in docker-compose.yml
```

### **"Cannot connect to Neo4j"**

```bash
# Check logs
docker compose logs neo4j

# Restart
docker compose restart neo4j
```

### **"Out of memory"**

```bash
# Increase Docker memory:
# Docker Desktop → Settings → Resources → Memory
# Recommended: 4GB minimum
```

### **"Schema already exists"**

This is normal - schemas are idempotent. Safe to ignore.

---

## 💾 **DATA PERSISTENCE**

All data is stored in Docker volumes:

```bash
# List volumes
docker volume ls | grep ctas7

# Backup Neo4j data
docker compose exec neo4j neo4j-admin database dump neo4j --to-path=/backups

# Restore
docker compose exec neo4j neo4j-admin database load neo4j --from-path=/backups
```

---

## 🔒 **SECURITY NOTES**

**Default passwords are for LOCAL DEVELOPMENT ONLY!**

For production:
1. Change all passwords in `.env`
2. Enable SSL/TLS
3. Use secrets management
4. Enable authentication on Redis
5. Use Supabase RLS policies

---

## 📚 **NEXT STEPS**

1. ✅ Verify deployment (see above)
2. ✅ Run threat content fetcher
3. ✅ Load all 27 sources
4. ✅ Build frontend integration
5. ✅ Deploy to production

---

## 💰 **COSTS**

```
Docker/OrbStack: $0
Neo4j (local):   $0
Redis (local):   $0
ChromaDB:        $0
PostgreSQL:      $0
Supabase:        $0/month (free tier)
Neon:            $0/month (free tier)

TOTAL: $0/month
```

---

## ✅ **SUCCESS CRITERIA**

- [ ] All Docker services healthy
- [ ] Neo4j accessible at localhost:7474
- [ ] PostgreSQL has tool_registry table
- [ ] ALL genomes are 16 hex chars (Murmur3-64)
- [ ] NO SHA-224 contamination (56 hex)
- [ ] Dual trivariates present
- [ ] Data loaded successfully

---

**Ready to deploy!** 🚀

Run: `./deploy_backend.sh`
