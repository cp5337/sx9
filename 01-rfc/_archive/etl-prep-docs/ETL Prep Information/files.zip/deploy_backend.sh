#!/bin/bash
# ============================================================================
# RFC-9005 Backend Stack - Quick Start
# ============================================================================
#
# This script:
# 1. Starts all backend services (Neo4j, Sledis, ChromaDB, PostgreSQL)
# 2. Initializes database schemas
# 3. Loads threat intelligence data
# 4. Validates RFC compliance
#
# Usage:
#   ./deploy_backend.sh
#
# ============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
print_header() {
    echo -e "\n${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Check prerequisites
print_header "Checking Prerequisites"

if ! command -v docker &> /dev/null; then
    print_error "Docker not found. Please install Docker or OrbStack."
    exit 1
fi
print_success "Docker found"

if ! command -v python3 &> /dev/null; then
    print_error "Python 3 not found. Please install Python 3.9+."
    exit 1
fi
print_success "Python 3 found"

# Check for .env file
if [ ! -f .env ]; then
    print_warning ".env file not found"
    echo "Creating from template..."
    cp .env.example .env
    print_warning "Please edit .env with your Supabase and Neon credentials"
    echo "Then run this script again."
    exit 0
fi
print_success ".env file found"

# Load environment
source .env

# Start backend services
print_header "Starting Backend Services"

echo "Starting Docker Compose stack..."
docker compose up -d

# Wait for services to be healthy
print_header "Waiting for Services to be Ready"

echo -n "Neo4j... "
until docker compose exec -T neo4j cypher-shell -u neo4j -p "$NEO4J_PASSWORD" "RETURN 1" &> /dev/null; do
    echo -n "."
    sleep 2
done
print_success "Neo4j ready"

echo -n "Redis/Sledis... "
until docker compose exec -T redis redis-cli ping &> /dev/null; do
    echo -n "."
    sleep 1
done
print_success "Redis ready"

echo -n "ChromaDB... "
until curl -sf http://localhost:8000/api/v1/heartbeat &> /dev/null; do
    echo -n "."
    sleep 1
done
print_success "ChromaDB ready"

echo -n "PostgreSQL... "
until docker compose exec -T postgres pg_isready -U ctas7 -d ctas7_dev &> /dev/null; do
    echo -n "."
    sleep 1
done
print_success "PostgreSQL ready"

# Initialize Neo4j schema
print_header "Initializing Database Schemas"

echo "Loading Neo4j schema..."
docker compose exec -T neo4j cypher-shell -u neo4j -p "$NEO4J_PASSWORD" < neo4j_schema.cypher
print_success "Neo4j schema loaded"

echo "PostgreSQL schema already loaded via init script"
print_success "PostgreSQL schema ready"

# Check Supabase connection
print_header "Validating Cloud Connections"

if [ -n "$SUPABASE_URL" ] && [ -n "$SUPABASE_KEY" ]; then
    print_success "Supabase configured"
else
    print_warning "Supabase not configured - update .env"
fi

if [ -n "$NEON_DATABASE_URL" ]; then
    print_success "Neon configured"
else
    print_warning "Neon not configured - using local PostgreSQL"
fi

# Load threat intelligence
print_header "Loading Threat Intelligence Data"

echo "Running RFC-9005 unified loader..."
python3 rfc9005_unified_loader.py \
    --threat-content "${THREAT_CONTENT_DIR:-./node-interview-generator/output/threat_content}"

# Validate RFC compliance
print_header "Validating RFC Compliance"

echo "Checking for SHA contamination in Neo4j..."
CONTAMINATED=$(docker compose exec -T neo4j cypher-shell -u neo4j -p "$NEO4J_PASSWORD" \
    "MATCH (n) WHERE n.genome IS NOT NULL AND size(n.genome) <> 16 RETURN count(n)" \
    | grep -o '[0-9]*' || echo "0")

if [ "$CONTAMINATED" -eq 0 ]; then
    print_success "No SHA contamination found - all genomes are 16 hex chars (Murmur3-64)"
else
    print_error "Found $CONTAMINATED nodes with non-compliant genome hashes!"
fi

echo "Checking dual trivariates in Neo4j..."
docker compose exec -T neo4j cypher-shell -u neo4j -p "$NEO4J_PASSWORD" \
    "MATCH (t:Tool) RETURN count(t.triv_hash_operational) as ops, count(t.triv_hash_semantic) as sem, count(t) as total"

# Summary
print_header "Deployment Complete"

echo ""
echo "🎯 Backend Services:"
echo "   • Neo4j Browser:    http://localhost:7474"
echo "   • PgAdmin:          http://localhost:5050 (if enabled)"
echo "   • ChromaDB:         http://localhost:8000"
echo "   • Redis:            localhost:6379"
echo ""
echo "📊 Database Statistics:"
docker compose exec -T neo4j cypher-shell -u neo4j -p "$NEO4J_PASSWORD" \
    "MATCH (n) RETURN labels(n)[0] as type, count(*) as count ORDER BY count DESC" || true
echo ""
echo "🔍 Next Steps:"
echo "   1. Check Neo4j Browser: http://localhost:7474"
echo "   2. Verify data loaded correctly"
echo "   3. Run additional loaders for MITRE, Sigma, etc."
echo ""

print_success "All services running!"
