# RFC-9028 — Uncertainty & Confidence Algebra (UCA)
Series: Cognitive (9020–9029)
Status: Draft

[Harvest version placeholder. Full draft exists in session context.]
