# RFC-9029 — Dynamic Domain Adaptation (DDA)
Series: Cognitive (9020–9029)
Status: Draft

[Harvest version placeholder. Full draft exists in session context.]
