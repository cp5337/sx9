# RFC-9027 — Inference Propagation Kernel (IPK)
Series: Cognitive (9020–9029)
Status: Draft → Canonical

[Harvest version placeholder. Full draft exists in session context.]
