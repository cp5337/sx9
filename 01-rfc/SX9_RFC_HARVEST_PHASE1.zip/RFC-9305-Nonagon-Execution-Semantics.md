# RFC-9305 — Nonagon Execution Semantics
Series: Core Graph & Analytics (9300–9399)
Status: Draft

[Harvest version placeholder. Full draft exists in session context.]
