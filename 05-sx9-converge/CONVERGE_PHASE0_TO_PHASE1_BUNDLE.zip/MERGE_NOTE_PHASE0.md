MERGE NOTE – PHASE 0 COMPLETE

- Deterministic relationship parsing fixed
- A* tie-breaking made deterministic (heuristic-aware)
- Workflow simulator breakpoints implemented

All tests pass.
Safe to merge.
Proceed to CONVERGE Phase 1.
